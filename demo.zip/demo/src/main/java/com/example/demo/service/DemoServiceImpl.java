package com.example.demo.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.controller.DemoController;
import com.example.demo.dto.Asset;

@Service
public class DemoServiceImpl implements DemoService {

	Logger log = LoggerFactory.getLogger(DemoController.class);
	RestTemplate restTemplate = new RestTemplate();

	@Override
	public void getModernDetails(long id) {
		@SuppressWarnings("rawtypes")
		RequestEntity request;

		try {
			request = RequestEntity.get(new URI("http://localhost:8081/modern/moderndetails/"+id)).build();

			ResponseEntity<List<Asset>> response = restTemplate.exchange(request, new ParameterizedTypeReference<List<Asset>>() {
			});
			log.info("======= Status: " + response.getBody());
			response.getBody().forEach(l->{
				log.info("assetName"+l.getAssetname());
				log.info("assetName"+l.getVersion());
		
			});
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

	}

}
