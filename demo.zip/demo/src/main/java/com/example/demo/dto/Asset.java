package com.example.demo.dto;

public class Asset {

	private long assetid;
	private String assetname;
	private double version;
	
	
	
	public long getAssetid() {
		return assetid;
	}
	public void setAssetid(long assetid) {
		this.assetid = assetid;
	}
	public String getAssetname() {
		return assetname;
	}
	public void setAssetname(String assetname) {
		this.assetname = assetname;
	}
	
	
	
	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}
	public Asset(long assetid, String assetname, double version) {
		super();
		this.assetid = assetid;
		this.assetname = assetname;
		this.version = version;
	}
	
	public Asset() {
		super();
	}
		
}
