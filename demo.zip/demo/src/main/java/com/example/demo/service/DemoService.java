package com.example.demo.service;

public interface DemoService {
	
	public void getModernDetails(long id);

}
