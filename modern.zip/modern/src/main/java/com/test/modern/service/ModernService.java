package com.test.modern.service;

import java.util.List;

import com.test.modern.dto.Asset;

public interface ModernService {
	
	public List<Asset> getModernDetails(long id);

}
