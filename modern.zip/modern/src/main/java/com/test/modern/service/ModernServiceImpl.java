package com.test.modern.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.test.modern.controller.ModernController;
import com.test.modern.dto.Asset;

@Service
public class ModernServiceImpl implements ModernService {

	Logger log = LoggerFactory.getLogger(ModernController.class);

	static List<Asset> lstDefAsset = new ArrayList<Asset>();

	@Override
	public List<Asset> getModernDetails(long id) {
		log.info("id.............." + id);

		return lstDefAsset.stream().filter(asset -> asset.getAssetid() == id).collect(Collectors.toList());

	}

	static {

		lstDefAsset.add(new Asset(1001, "Dell PC", 1.0));
		lstDefAsset.add(new Asset(1002, "Mac OS", 1.2));
		lstDefAsset.add(new Asset(1003, "Window OS", 1.3));

	}

}
